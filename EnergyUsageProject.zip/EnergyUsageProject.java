
import java.util.*;

class RoomEnergy {
    String room;
    double daily;

    RoomEnergy(String room, double daily) {
        this.room = room;
        this.daily = daily;
    }
}

public class EnergyUsageProject {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<RoomEnergy> rooms = new ArrayList<>();
    static HashMap<String, Double> monthlyBills = new HashMap<>();

    static boolean login() {

        String correctUser = "admin";
        String correctPass = "1234";

        System.out.println("===== ENERGY MONITOR LOGIN =====");

        System.out.print("Username: ");
        String user = sc.next();

        System.out.print("Password: ");
        String pass = sc.next();

        if (user.equals(correctUser) && pass.equals(correctPass)) {
            System.out.println("Login Successful\n");
            return true;
        }

        System.out.println("Invalid Login");
        return false;
    }

    static void addRoomUsage() {

        System.out.print("Enter Room Name: ");
        String room = sc.next();

        System.out.print("Enter Daily Units Used: ");
        double units = sc.nextDouble();

        rooms.add(new RoomEnergy(room, units));

        System.out.println("Data Added\n");
    }

    static void showUsage() {

        for (RoomEnergy r : rooms) {

            double weekly = r.daily * 7;
            double monthly = r.daily * 30;

            System.out.println("\nRoom: " + r.room);
            System.out.println("Daily Units: " + r.daily);
            System.out.println("Weekly Units: " + weekly);
            System.out.println("Monthly Units: " + monthly);
        }

        System.out.println();
    }

    static void highestEnergyRoom() {

        if (rooms.isEmpty()) return;

        RoomEnergy max = rooms.get(0);

        for (RoomEnergy r : rooms) {
            if (r.daily > max.daily)
                max = r;
        }

        System.out.println("Highest Energy Usage Room: " + max.room);
        System.out.println("Daily Units: " + max.daily + "\n");
    }

    static void showGraph() {

        System.out.println("\nEnergy Consumption Graph");

        for (RoomEnergy r : rooms) {

            System.out.print(r.room + " : ");

            int bars = (int) r.daily;

            for (int i = 0; i < bars; i++)
                System.out.print("*");

            System.out.println(" " + r.daily + " units");
        }

        System.out.println();
    }

    static void generateBill() {

        System.out.print("Enter Month Name: ");
        String month = sc.next();

        double total = 0;

        for (RoomEnergy r : rooms)
            total += r.daily * 30;

        double rate = 6.5;

        double bill = total * rate;

        monthlyBills.put(month, bill);

        System.out.println("Total Units: " + total);
        System.out.println("Bill for " + month + " : ₹" + bill + "\n");
    }

    static void compareBills() {

        System.out.println("\nMonthly Bill Comparison");

        for (String m : monthlyBills.keySet()) {

            double bill = monthlyBills.get(m);

            System.out.print(m + " : ");

            int bars = (int) (bill / 100);

            for (int i = 0; i < bars; i++)
                System.out.print("*");

            System.out.println(" ₹" + bill);
        }

        System.out.println();
    }

    public static void main(String[] args) {

        if (!login())
            return;

        int choice;

        do {

            System.out.println("===== ENERGY MONITOR MENU =====");
            System.out.println("1 Add Room Power Usage");
            System.out.println("2 Show Daily/Weekly/Monthly Usage");
            System.out.println("3 Room with Highest Energy Usage");
            System.out.println("4 Show Energy Graph");
            System.out.println("5 Generate Electricity Bill");
            System.out.println("6 Compare Monthly Bills");
            System.out.println("7 Exit");

            System.out.print("Enter Choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    addRoomUsage();
                    break;

                case 2:
                    showUsage();
                    break;

                case 3:
                    highestEnergyRoom();
                    break;

                case 4:
                    showGraph();
                    break;

                case 5:
                    generateBill();
                    break;

                case 6:
                    compareBills();
                    break;

                case 7:
                    System.out.println("System Exit");
                    break;

                default:
                    System.out.println("Invalid Choice\n");
            }

        } while (choice != 7);
    }
}
